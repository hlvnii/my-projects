
import java.util.LinkedList; 
import java.util.Queue; 
  
public class fifo { 
    public static void main(String[] args) 
    { 
        Queue<Integer> q = new LinkedList<>(); 
  
        // Adds elements {0, 1, 2, 3, 4} to queue 
        for (int k = 1; k < 6; k++) 
            q.add(k); 
   
        System.out.println("Elements of queue-" + q); 
  
      
        int removedele = q.remove(); 
        System.out.println("removed element-" + removedele); 
  
        System.out.println(q); 
  
     
        int head = q.peek(); 
        System.out.println("head of queue-" + head); 
  
        int size = q.size(); 
        System.out.println("size of queue-" + size); 
    } 
} 