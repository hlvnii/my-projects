import java.util.Scanner;
 
class sjf 
{
    public static void main(String args[])
    {
        int processes[] = new int[10];
        int processTime[] = new int[10];
        int waitingTime[] = new int[10];
        int temp, n, total=0;
        float avg=0;
        Scanner get = new Scanner(System.in);
 
       System.out.println("Please Enter the Number of processeses:");
        n = get.nextInt();
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter processes "+(i+1)+" No.: ");
            processes[i] = get.nextInt();
            System.out.println("Enter processes "+(i+1)+" Burst Time: ");
            processTime[i] = get.nextInt();
        }
			waitingTime[0] = 0;
			for(int i=1;i<n;i++)
			{
				waitingTime[i] = waitingTime[i-1]+processTime[i-1];
				total = total + waitingTime[i];
			}
			avg = (float)total/n;
			System.out.println("Process_No. Process_TIME Waiting_TIME");
			for(int i=0;i<n;i++)
			{
				System.out.println(processes[i]+"\t"+processTime[i]+"\t"+waitingTime[i]);
			}
			System.out.println("Total Waiting Time: "+total);
			System.out.println("Average Waiting Time: "+avg);
	 
        for(int i=0;i<n-1;i++)
        {
            for(int j=i+1;j<n;j++) 
			{
				if(processTime[i]>processTime[j])
                {
                    temp = processTime[i];
                    processTime[i] = processTime[j];
                    processTime[j] = temp;
                    temp = processes[i];
                    processes[i] = processes[j];
                    processes[j] = temp;
                }
            }
        }
 
        
    }
}

